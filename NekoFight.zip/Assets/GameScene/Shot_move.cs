﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shot_move : MonoBehaviour
{
    Vector3 move=new Vector3(0.15f,0,0);
    // Start is called before the first frame update
    void Start()
    {
        transform.rotation=GameObject.Find("Boss(Clone)").transform.rotation;
        if(transform.position.y+1>GameObject.Find("Player").transform.position.y) this.move.y=-0.02f;
        else if(transform.position.y-1<GameObject.Find("Player").transform.position.y) this.move.y=0.01f;
        else this.move.y=0;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(this.move);
        Destroy(gameObject,5);
    }
}
