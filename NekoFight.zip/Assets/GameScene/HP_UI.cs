﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HP_UI : MonoBehaviour
{
    Player_move Player;
    Image d,m,s;
    // Start is called before the first frame update
    void Start()
    {
        this.Player=GameObject.Find("Player").GetComponent<Player_move>();
        this.d=GameObject.Find("denger").GetComponent<Image>();
        this.m=GameObject.Find("medium").GetComponent<Image>();
        this.s=GameObject.Find("safe").GetComponent<Image>();
    }

    // Update is called once per frame
    void Update()
    {
        switch(this.Player.HP){
            case 1:
            this.d.fillAmount=0.5f;
            this.m.fillAmount=0;
            this.s.fillAmount=0;
            break;
            case 2:
            this.d.fillAmount=1;
            this.m.fillAmount=0;
            this.s.fillAmount=0;
            break;
            case 3:
            this.d.fillAmount=1;
            this.m.fillAmount=0.5f;
            this.s.fillAmount=0;
            break;
            case 4:
            this.d.fillAmount=1;
            this.m.fillAmount=1;
            this.s.fillAmount=0;
            break;
            case 5:
            this.d.fillAmount=1;
            this.m.fillAmount=1;
            this.s.fillAmount=0.5f;
            break;
            case 6:
            this.d.fillAmount=1;
            this.m.fillAmount=1;
            this.s.fillAmount=1;
            break;
            default:
            this.d.fillAmount=0;
            this.m.fillAmount=0;
            this.s.fillAmount=0;
            break;
        }
    }
}
