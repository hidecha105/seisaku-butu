﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire_move : MonoBehaviour
{
    Transform boss;
    // Start is called before the first frame update
    void Start()
    {
        this.boss=GameObject.Find("Boss(Clone)").transform;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 pos=transform.position;
        transform.eulerAngles=boss.eulerAngles;
        if(boss.eulerAngles.y==180) pos.x=this.boss.position.x-0.9f;
        else pos.x=this.boss.position.x+0.9f;
        pos.y=this.boss.position.y+0.4f;
        transform.localPosition=pos;
        Destroy(gameObject,1);
    }
}
