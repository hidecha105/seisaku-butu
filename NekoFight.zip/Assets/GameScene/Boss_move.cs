﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_move : MonoBehaviour
{
    // Start is called before the first frame update
    float  at,time=0;
    Vector3 mov;
    Transform player;
    public GameObject shotPrefab,firePrefab;
    public int hp=12;
    Animator animator;
    
    void Start()
    {
        player=GameObject.Find("Player").transform;
        this.mov=new Vector3(0,0.003f,0);
        this.at=Random.Range(1,5);
        this.animator=GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(hp>0){
            this.time+=Time.deltaTime;
            transform.Translate(this.mov);
            if(transform.position.x>player.position.x) transform.eulerAngles=new Vector3(0,180,0);
            else transform.eulerAngles=new Vector3(0,0,0);
            if(this.time>=this.at){
                this.animator.SetTrigger("attack");
                float dis=Vector3.Distance(transform.position,player.position);
                if(dis<=3) Fire();
                else Shot();
                this.time=0;
            }
        }else{
            this.animator.SetTrigger("lose");
            Destroy(gameObject,3);
        }
    }
    void Fire(){
        GameObject go=Instantiate(firePrefab)as GameObject;
        go.transform.position=transform.position;
        go.transform.rotation=transform.rotation;
        this.at=Random.Range(3,6);
    }
    void Shot(){
        GameObject go=Instantiate(shotPrefab)as GameObject;
        go.transform.position=transform.position;
        this.at=Random.Range(1,5);
    }
    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.tag=="wall") mov.y*=-1;
        if(other.gameObject.tag=="player_attack"){
            this.hp-=1;
        }
    }
}
