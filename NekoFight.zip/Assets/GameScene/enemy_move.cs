﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy_move : MonoBehaviour
{
    public int HP=3;
    Transform player;
    Vector3 move;
    Animator animator;
    Transform box;
    float time=0,range,bt,st;
    int scene=1;
    // Start is called before the first frame update
    void Start()
    {
        this.player=GameObject.Find("Player").transform;
        this.box=transform.GetChild(0);
        st=Random.Range(0f,1f);
        range=Random.Range(1.3f,2f);
        move.x=Random.Range(0.05f,0.1f);
        move.y=Random.Range(0.0f,0.05f);
        move.z=0;
        this.animator=GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(this.HP<=0){Destroy(gameObject);}
        switch(this.scene){
            case 1:stay();
            break;
            case 2:attack();
            break;
            case 3:stop();
            break;
            default:back();
            break;
        }
        
    }
    void stay(){
        this.time+=Time.deltaTime;
        transform.Translate(move);
        if(this.time>this.st){
            range=Random.Range(1.3f,2.5f);
            this.scene=2;
            this.time=0;
        }
    }
    void attack(){
        if(transform.position.x>player.position.x) transform.eulerAngles=new Vector3(0,180,0);
        else transform.eulerAngles=new Vector3(0,0,0);
        float aa;
        if(player.position.y+0.3<transform.position.y){
            move.y=-0.006f;
        }else if(player.position.y-0.3>transform.position.y){
            move.y=0.006f;
        }else{
            move.y=0;
        }
        if(player.position.x+this.range-0.2<=transform.position.x){
            move.x=-0.008f;
        }else if(player.position.x-this.range+0.2>=transform.position.x){
            move.x=0.008f;
        }else{
            move.x=0;
        }
        if((aa=player.position.x-transform.position.x)<0){
            aa*=-1.6f;
        }
        if(this.range>=aa&&move.y==0){
            this.animator.SetTrigger("attackTrigger");
            bt=Random.Range(1f,3f);
            move.x=Random.Range(-0.008f,0.008f);
            move.y=Random.Range(-0.005f,0.005f);
            this.scene=3;
            this.box.gameObject.SetActive(true);
        }
        transform.position+=move;//Translate(move);
    }
    void stop(){
        this.time+=Time.deltaTime;
        if(this.time>=1){
            this.time=0;
            this.scene=4;
            this.box.gameObject.SetActive(false);
        }
    }
    void back(){
        this.time+=Time.deltaTime;
        if(this.time<this.bt) transform.position+=move;//Translate(move);
        else{
            st=Random.Range(0.5f,2f);
            move.x=Random.Range(0.005f,0.008f);
            move.y=Random.Range(0.0f,0.004f);
            this.time=0;
            this.scene=1;
        }
    }
    void OnTriggerStay2D(Collider2D other){
        if(other.gameObject.tag=="wall"){
            move.x=0;
            move.y=0;
        }
    }
    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.tag=="player_attack"){
            this.HP-=1;
            if(player.position.x+this.range-0.2<=transform.position.x)this.move.x=4;
            else this.move.x=-0.009f;
            move.y=0;
            transform.Translate(move);
            move.x=Random.Range(-0.008f,0.008f);
            move.y=Random.Range(-0.004f,0.004f);
            this.scene=0;
        }
    }
}
