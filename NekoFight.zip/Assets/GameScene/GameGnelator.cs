﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameGnelator : MonoBehaviour
{
    // Start is called before the first frame update
    int i=-1;
    bool c=true;
    float time;
    int[] spon={3,5,6};
    public GameObject enemy_1,enemy_2,enemy_boss;
    GameObject enemy;
    GameObject player;
    GameObject[] coun;
    void Start()
    {
        player=GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        if(i<3){
            coun=GameObject.FindGameObjectsWithTag("enemy");
            if(c==true){
                this.time+=Time.deltaTime;
                if(this.time>=3){
                    i++;
                    c=false;
                    this.time=0;
                }
            }else if(3>this.coun.Length){
                if(spon[i]!=0){
                    enemy=Instantiate(enemy_1)as GameObject;
                    enemy.transform.position=new Vector3(-10,Random.Range(-5f,1f),0);
                    spon[i]--;
                }else if(this.coun.Length==0&&spon[i]==0){
                    c=true;
                    this.player.GetComponent<Player_move>().HP+=2;
                }
            }
        }else if(i==3){
            if(this.time==0){
                enemy=Instantiate(enemy_boss)as GameObject;
                enemy.transform.position=new Vector3(-10,0,0);
                this.time+=Time.deltaTime;
            }else if(this.time<=2){
                enemy.transform.Translate(0.005f,0,0);
                this.time+=Time.deltaTime;
            }else{
                coun=GameObject.FindGameObjectsWithTag("enemy");
                if(0==this.coun.Length) SceneManager.LoadScene("loseScene");//勝利画面
            }
        }
        if(player==null){
            SceneManager.LoadScene("loseScene");
        }
    }
}
