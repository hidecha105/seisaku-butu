﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_move : MonoBehaviour
{
    public int HP=6;
    bool pt=false,kk=false;
    float time,muteki=3;
    Animator animator;
    // Start is called before the first frame update
    void Start()
    {
        this.animator=GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        this.muteki+=Time.deltaTime;
        if(HP==0){
            Destroy(gameObject,3);
        }else if(this.pt==true){
            this.time+=Time.deltaTime;
            if(this.time>=0.3){
                transform.GetChild(0).gameObject.SetActive(false);
                this.pt=false;
            }
        }else if(this.kk==true){
            this.time+=Time.deltaTime;
            if(this.time>=0.5){
                transform.GetChild(2).gameObject.SetActive(false);
                this.kk=false;
            }else if(this.time>=0.1){
                transform.GetChild(1).gameObject.SetActive(false);
                transform.GetChild(2).gameObject.SetActive(true);
            }
        }else{
            if (Input.GetKey(KeyCode.A)&&transform.position.x>=-7.5){
                transform.Translate(new Vector2(0.01f,0));
                transform.eulerAngles=new Vector3(0,180,0);
            }
            else if(Input.GetKey(KeyCode.D)&&transform.position.x<=8){
                transform.Translate(new Vector2(0.01f,0));
                transform.eulerAngles=new Vector3(0,0,0);
            }
            if(Input.GetKey(KeyCode.W)&&transform.position.y<=1)transform.Translate(new Vector2(0,0.005f));
            else if(Input.GetKey(KeyCode.S)&&transform.position.y>=-4)transform.Translate(new Vector2(0,-0.005f));
            if(Input.GetKeyDown(KeyCode.Return)){
                Debug.Log("pant");
                pant();
            }else if(Input.GetKeyDown(KeyCode.RightShift)){
                Debug.Log("kick");
                kick();
            }
        }
    }
    void pant(){
        this.animator.SetTrigger("Panche");
        transform.GetChild(0).gameObject.SetActive(true);
        this.pt=true;
        this.time=0;
    }
    void kick(){
        this.animator.SetTrigger("Kikku");
        transform.GetChild(1).gameObject.SetActive(true);
        this.kk=true;
        this.time=0;
    }
    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.tag=="enemy_attack"&&muteki>=3){
            HP-=1;
            this.muteki=0;
        }
    }
}
