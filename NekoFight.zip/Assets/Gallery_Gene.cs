﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gallery_Gene : MonoBehaviour
{
    GameObject but;
    // Start is called before the first frame update
    void Start()
    {
    this.but=GameObject.Find("Button (1)").transform.GetChild(0).gameObject;
    }

    // Update is called once per frame
    void Update()
    {
    }
    public void ButtonClicked(){}
    public void Dora(){
        this.but.SetActive(false);
        this.but=GameObject.Find("Button (1)").transform.GetChild(0).gameObject;
        this.but.SetActive(true);
    }
    public void Ene(){
        this.but.SetActive(false);
        this.but=GameObject.Find("Button (2)").transform.GetChild(0).gameObject;
        this.but.SetActive(true);
    }
    public void Boss(){
        this.but.SetActive(false);
        this.but=GameObject.Find("Button (3)").transform.GetChild(0).gameObject;
        this.but.SetActive(true);
    }
    public void Del(){
        this.but.SetActive(false);
        this.but=GameObject.Find("Button (4)").transform.GetChild(0).gameObject;
        this.but.SetActive(true);
    }
}
