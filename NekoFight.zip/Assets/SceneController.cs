﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class SceneController : MonoBehaviour
{
    public void ButtonClicked()
    {
        SceneManager.LoadScene("gallery");
    }
    public void GoGame(){
        SceneManager.LoadScene("GameScene");
    }

// Start is called before the first frame update
void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
